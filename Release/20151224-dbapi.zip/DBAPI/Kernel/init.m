(* Mathematica Init File *)

Get[ "DBAPI`Utils`"];
Get[ "DBAPI`OrientDB`"];
